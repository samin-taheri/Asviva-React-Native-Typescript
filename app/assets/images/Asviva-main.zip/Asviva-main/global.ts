export const primaryColor = '#0056b3';
export const secondaryColor = '#93bffc';
export const textColor = '#6c6c6c';
export const backgroundColor = '#f5f5f5';
export const thirdColor = '#2383e8';
