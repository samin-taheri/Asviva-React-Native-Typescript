import Navigation from './navigation/index';

export default function App() {

    return (
      <>
       <Navigation />
      </>
     );
  } 
